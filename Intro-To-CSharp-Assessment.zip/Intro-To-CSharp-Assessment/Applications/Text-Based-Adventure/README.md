# How To Play
The user will enter what they want to do into the console in the form of numbers and words.  
There are five different floors, and upon defeating an enemy, you will gain their reward money and also be able to move to the next floor.  
There are also items that the players can use. The player can only equip one item at a time, and healing items are used up when you equip them. 
Players can visit the shop to buy new items, but they can only buy items that are from their own class.
