﻿using System;

namespace Text_Based_Adventure
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create a new instance of Game
            Game game = new Game();

            //Run the Game
            game.Run();
        }
    }
}
